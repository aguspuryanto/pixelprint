<?php
date_default_timezone_set("Asia/Jakarta");

echo date('Y-m-d H:i:s', strtotime('2018-03-31'));