<?php
return [
    'settings' => [
		'debug' => true,
		'determineRouteBeforeAppMiddleware' => false,
        'displayErrorDetails' => true, // set to false in production
        'addContentLengthHeader' => false, // Allow the web server to send the content-length header
		'db' => [
            'driver' => 'mysql',
            'host' => 'localhost',
            'database' => 'giinesia_wp892',
            'username' => 'giinesia_wp892',
            'password' => 'CX9]4S!2pq',
            'charset'   => 'utf8',
            'collation' => 'utf8_unicode_ci',
            'prefix'    => '',
        ]
    ],
];
